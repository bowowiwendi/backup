const chalk = require("chalk")
const fs = require("fs")

  global.ownerNumber = "6283153170199@s.whatsapp.net"
  global.kontakOwner = "6283153170199"
  global.namaStore = "WENDI STORE"
  global.botName = "WENDI STORE BOT"
  global.ownerName = "WENDI WIBOWO"
  
  
  global.linkyt = "link chanel yt lu"
  global.linkig = "link akun ig lu"
  global.dana = "083153170199"
  global.sawer = "083153170199"


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})