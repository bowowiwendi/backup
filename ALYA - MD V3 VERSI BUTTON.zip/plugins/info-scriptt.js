import fs from 'fs'

let handler = async (m, { conn }) => {
  let info = `*「  Alya-MD - DE4YOU YT 」*
╭─────────────────────
│ 🚀 *Whatsapp Bot ALYA - MD-MD*
│
│ ⚙️ *Base Type:* ES Module (ESM)
│ 🔐 *Security:* Anti-Tag All Group
│ 🧠 *AI Mode:* Chat & Response Ready
│ 📊 *Fitur:* Rpg | Store | Topup
│ 🔍 *Scrape & API:* 50/50
│ 🛠 *Stability:* 78% Tested
│ 🎮 *Game Menu:* Full Unlock
│ 📌 *Style Menu:* Button & Pagination
│
│ [✉️] *Chat Support:* wa.me/6287778002663
│ [🧾] *Update Info:* https://whatsapp.com/channel/0029VbAzDcXChq6RkzvRKp2k
╰─────────────────────`.trim()

  await conn.sendMessage(m.chat, {
    text: info,
    contextInfo: {
      externalAdReply: {
        title: `[ WARNING ] SCRIPT INI TIDAK GRATIS`,
        body: `Laporkan Jika Ada Yang Menjual`,
        thumbnailUrl: `https://files.catbox.moe/14enxv.jpg`,
        sourceUrl: `https://whatsapp.com/channel/0029Vb2L4fu8KMqpesPWmB17`,
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  }, { quoted: m })
}

handler.command = /^(sc|script|sourcecode)$/i
export default handler