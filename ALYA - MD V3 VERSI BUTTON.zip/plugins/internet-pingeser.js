const {
    proto,
    generateWAMessageFromContent,
    generateWAMessageContent, 
    prepareWAMessageMedia
  } = (await import('@adiwajshing/baileys')).default
import gis from 'g-i-s'

async function pinterest(query) {
  return new Promise((resolve, reject) => {
    gis({ searchTerm: query + ' site:id.pinterest.com' }, (err, res) => {
      if (err) return reject({ status: 404, message: 'Terjadi kesalahan' })
      let hasil = res.map(x => x.url)
      resolve(hasil)
    })
  })
}

function shuffleArray(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[array[i], array[j]] = [array[j], array[i]]
  }
}

async function createImage(url, conn) {
  const { imageMessage } = await generateWAMessageContent(
    { image: { url } },
    { upload: conn.waUploadToServer }
  )
  return imageMessage
}

let handler = async (m, { conn, text, command }) => {
  if (!text) return m.reply('Mau cari apa?')

  m.reply('🔍 Mencari gambar...')

  let results = await pinterest(text)
  shuffleArray(results)

  let selected = results.slice(0, 10)
  let i = 1
  let cards = []

  for (let url of selected) {
    cards.push({
      body: proto.Message.InteractiveMessage.Body.fromObject({ text: 'Hasil pencarian Pinterest' }),
      footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: 'Pinterest Bot' }),
      header: proto.Message.InteractiveMessage.Header.fromObject({
        title: `Gambar - ${i++}`,
        hasMediaAttachment: true,
        imageMessage: await createImage(url, conn)
      }),
      nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
        buttons: [
          {
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({
              display_text: 'Lihat Pinterest',
              url: `https://www.pinterest.com/search/pins/?q=${encodeURIComponent(text)}`
            })
          }
        ]
      })
    })
  }

  const msg = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
          body: proto.Message.InteractiveMessage.Body.create({ text: 'Berikut hasilnya:' }),
          footer: proto.Message.InteractiveMessage.Footer.create({ text: 'Pinterest Bot' }),
          header: proto.Message.InteractiveMessage.Header.create({ hasMediaAttachment: false }),
          carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
            cards
          })
        })
      }
    }
  }, { quoted: m })

  await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

handler.command = ['pinges','pingeser','pinterestv2']
handler.help = ['pinges','pingeser','pinterestv2']
handler.tags = ['internet']
handler.limit = false
handler.premium = false

export default handler