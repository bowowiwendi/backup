import fetch from "node-fetch";

let handler = async (m, { conn, text }) => {
  if (!text) {
    return m.reply(`linknya mana yaa?
~ (All Media): https://www.instagram.com/...
~ (All Stories): https://www.instagram.com/stories/username
Belum Support MP3 Yaa`);
  }

  m.reply("tunggu sebentar yaa..");

  try {
    let apiUrl = `https://apizell.web.id/download/instagram?url=${encodeURIComponent(text)}`;
    let response = await fetch(apiUrl);
    let data = await response.json();

    if (!data || !data.result) {
      return m.reply("Gaada media yang ditemukan.");
    }

    // Memastikan result adalah array, jika tidak, jadikan array
    let results = Array.isArray(data.result) ? data.result : [data.result];

    let title = results[0].meta.title || "No title available";
    let caption = `*Judul:*
${title}

*Download Success!*`;

    await conn.sendMessage(m.chat, { text: caption }, { quoted: m });

    // Kirim media sesuai urutannyaa
    for (let i = 0; i < results.length; i++) {
      let item = results[i];
      let media = item.url[0];

      if (media.ext === "mp4") {
        await conn.sendMessage(
          m.chat,
          {
            video: { url: media.url },
            mimetype: "video/mp4",
            fileName: `${title || "video_instagram"}.mp4`
          },
          { quoted: m }
        );
      } else if (media.ext === "jpg" || media.ext === "png" || media.ext === "heic") {
        await conn.sendMessage(
          m.chat,
          {
            image: { url: media.url }
          },
          { quoted: m }
        );
      }
    }
  } catch (e) {
    console.error(e);
    m.reply("Yahh lagi error kaa");
  }
};

handler.help = ["ig *link*"];
handler.tags = ["download"];
handler.command = ["ig", "instagram", "igdl"];

export default handler;