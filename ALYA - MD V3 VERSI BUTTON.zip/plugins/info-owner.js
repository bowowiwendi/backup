import fs from 'fs';

let handler = async (m, { conn }) => {
  let teks = `*「 👑 OWNER BOT 」*

 Nama: Alzai7 Store
 Kontak: wa.me/6285189748370
 Update Info : https://whatsapp.com/channel/0029Vb4aQte2phHSD0kR7N0G
Terima kasih sudah menggunakan bot Alya-MD!`;

  await conn.sendMessage(m.chat, {
    image: { url: 'https://img1.pixhost.to/images/5529/595423642_kyami.jpg' },
    caption: teks,
    buttons: [
      { buttonId: '.menu', buttonText: { displayText: '📋 Menu Bot' }, type: 1 },
      { buttonId: '.donasi', buttonText: { displayText: '💸 Donasi' }, type: 1 }
    ],
    footer: 'ALYA - MD V3 | Alzai7 Store',
    headerType: 4,
    contextInfo: {
      mentionedJid: [m.sender]
    }
  }, { quoted: m });
};

handler.help = ['owner'];
handler.tags = ['info'];
handler.command = /^(owner)$/i;

export default handler;