/*============== MOHON DIBACA ==============

BASE SCRIPT : ALYA - MD

DI RECODE OLEH : DE4YOU YT

SALURAN DE4YOU YT
https://whatsapp.com/channel/0029Vb2L4fu8KMqpesPWmB17

*/
import fetch from 'node-fetch'

const handler = async (m, { conn, text }) => {
  try {
    const res = await fetch('https://fgsi1-restapi.hf.space/api/information/mywaifulist/news')
    const json = await res.json()

    if (!json.status || !json.data) return m.reply('Gagal mengambil data berita.')

    let newsList = json.data.map((item, index) => {
      return `*${index + 1}. ${item.title}*\n${item.description}\n_Published: ${item.pubDate.split('T')[0]}_\n[Read More](${item.url})`
    }).join('\n\n')

    await conn.sendMessage(m.chat, {
      text: `*📢 MyWaifuList News*\n\n${newsList}`,
      contextInfo: {
        mentionedJid: [m.sender],
        externalAdReply: {
          title: 'Waifu News Center',
          body: 'Latest news from MyWaifuList',
          thumbnailUrl: 'https://files.catbox.moe/wv9mfj.jpg',
          sourceUrl: 'https://fgsi1-restapi.hf.space',
          mediaType: 1,
          renderLargerThumbnail: true,
          showAdAttribution: false
        },
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterName: "DE4YOU YT OFFICIAL",
          newsletterJid: `120363404369028369@newsletter`
        }
      }
    }, { quoted: m })

  } catch (e) {
    m.reply(`Gagal mengambil berita: ${e}`)
  }
}

handler.help = ['waifunews']
handler.tags = ['anime']
handler.command = ['waifunews']
handler.limit = true

export default handler