import axios from 'axios'
 
let handler = async (m, { text }) => {
  if (!text) return m.reply('Masukkan pertanyaan, contoh:\ngpt3 halo')
 
  try {
    let { data } = await axios.get('https://www.abella.icu/gpt-3.5?q=' + encodeURIComponent(text))
    if (data?.status == 'success') {
      m.reply(data.data.answer)
    } else {
      throw 'err'
    }
  } catch {
    m.reply('Gagal mendapatkan jawaban dari AI.')
  }
}
 
handler.help = ['gpt-3.5 <teks>']
handler.command = ['gpt-3.5']
handler.tags = ['ai']
 
export default handler