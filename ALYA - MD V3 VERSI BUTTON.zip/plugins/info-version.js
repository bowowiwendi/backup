import fs from 'fs';

let handler = async (m, { conn }) => {
  conn.reply(m.chat, `${conn.user.name} ᴠᴇʀsɪᴏɴ: *10.5.0*`, m, {
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        body: `ᴠᴇʀsɪᴏɴ 10.5.0`,
        thumbnailUrl: `https://files.catbox.moe/p8s7sk.jpg`,
        sourceUrl: '0029VaBOlsv002TEjlntTE2D',
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
};

handler.command = ['version', 'versi', 'v'];
handler.help = ['version'];
handler.tags = ['info'];

export default handler;