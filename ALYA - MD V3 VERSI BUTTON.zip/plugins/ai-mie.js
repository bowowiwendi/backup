import axios from 'axios';

let handler = async (m, { conn, text }) => {
  if (!text) return m.reply(" Masukkan pesan untuk Mie-AI!");

  try {
    await conn.sendMessage(m.chat, {
      react: { text: "🌸", key: m.key }
    });

    let apiUrl = `https://api.simplebot.my.id/api/tools/openai?prompt=sekarang%20kamu%20adalah%20Arona-AI&msg=${encodeURIComponent(text)}`;
    let { data } = await axios.get(apiUrl);

    if (!data.status || !data.result) {
      return m.reply("❌ Gagal mendapatkan respons dari Mie-AI.");
    }

    let replyMsg = `🤖 *Alya Ai Chatbot*\n\n` +
                   `💬 *Pertanyaan:* ${text}\n` +
                   `🧠 *Jawaban:* ${data.result}\n\n` +
                   `🔖 *Created by:* Arona AI`;

    m.reply(replyMsg);

    await conn.sendMessage(m.chat, {
      react: { text: "☑️", key: m.key }
    });

  } catch (error) {
    console.error(error);
    m.reply("❌ Terjadi kesalahan saat menghubungi Alya Ai.");
  }
};

// Handler bot
handler.help = ['arona <pesan>'];
handler.tags = ['ai'];
handler.command = ["arona", "ai"];

export default handler;;