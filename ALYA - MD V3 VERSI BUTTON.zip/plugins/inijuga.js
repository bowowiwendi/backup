let handler = async (m, { conn }) => {
	
	m.reply('iya gapapa sayang, lain kali jangan di ulangin lagi yaaaa..❤')
	
}


handler.command = /^(maaf|gomen|gomenasai)$/i

export default handler