process.on("warning", console.warn);
process.on("unhandledRejection", console.error);
process.on("uncaughtException", console.error);

const fs = require("fs");
const path = require("path");
const cp = require("child_process");
const db = require("./system/database.js");
const Config = require("./config.js");
const Connection = require("./system/connection.js");
const { loadPluginFiles } = require("./system/plugin.js");
const { serialize, protoType } = require("./system/simple.js");

start();
serialize();
protoType(); 
quickTest();
loadPluginFiles();

const file = path.join(__dirname, "system/plugin.js");
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.info("[ UPDATE ]", path.basename(file));
  delete require.cache[file];
  const module = require(file);
  module.loadPluginFiles();
});

async function start() {
  if (db.read) await db.read()
  const login = (await db.getAll())
    .filter(data => data.jadibot?.status)
  if (login.length) {
    console.info(`Loading connect ${login.length} session`);
    for (const data of login) {
      await Connection.start(null, { number: data._id });
    }
  } else
    await Connection.start(null, { number: Config.bot });
  setInterval(() => require("./cronjob.js")(), 60_000);
}

async function quickTest() {
  console.info("Quick test");
  const test = await Promise.all(
    [
      cp.spawn("ffmpeg"),
      cp.spawn("ffprobe"),
      cp.spawn("ffmpeg", [
        "-hide_banner",
        "-loglevel",
        "error",
        "-filter_complex",
        "color",
        "-frames:v",
        "1",
        "-f",
        "webp",
        "-",
      ]),
      cp.spawn("convert"),
      cp.spawn("magick"),
      cp.spawn("gm"),
      cp.spawn("find", ["--version"]),
    ].map((p) => {
      return Promise.race([
        new Promise((resolve) => {
          p.on("close", (code) => {
            resolve(code !== 127);
          });
        }),
        new Promise((resolve) => {
          p.on("error", (_) => resolve(false));
        }),
      ]);
    }),
  );
  const [ffmpeg, ffprobe, ffmpegWebp, convert, magick, gm, find] = test;
  const s = {
    ffmpeg,
    ffprobe,
    ffmpegWebp,
    convert,
    magick,
    gm,
    find,
  };
  Object.freeze(s);
  if (!s.ffmpeg)
    console.warn(
      "Please install ffmpeg for sending videos (pkg install ffmpeg)",
    );
  if (s.ffmpeg && !s.ffmpegWebp)
    console.warn(
      "Stickers may not animated without libwebp on ffmpeg (--enable-libwebp while compiling ffmpeg)",
    );
  if (!s.convert && !s.magick && !s.gm)
    console.warn(
      "Stickers may not work without imagemagick if libwebp on ffmpeg doesnt isntalled (pkg install imagemagick)",
    );
  return s;
}
