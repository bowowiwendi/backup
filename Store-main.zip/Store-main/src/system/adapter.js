const fs = require("fs");
const path = require("path");

const BufferJSON = {
  replacer: (k, value) => {
    if (
      Buffer.isBuffer(value) ||
      value instanceof Uint8Array ||
      value?.type === "Buffer"
    ) {
      return {
        type: "Buffer",
        data: Buffer.from(value?.data || value).toString("base64"),
      };
    }
    return value;
  },

  reviver: (_, value) => {
    if (
      typeof value === "object" &&
      !!value &&
      (value.buffer === true || value.type === "Buffer")
    ) {
      const val = value.data || value.value;
      return typeof val === "string"
        ? Buffer.from(val, "base64")
        : Buffer.from(val || []);
    }
    return value;
  },
};

class mongoDB {
  constructor(url, dbName = "mydb", collectionName = "data") {
    this.client = new (require("mongodb").MongoClient)(url, {
      serverSelectionTimeoutMS: 60 * 1000,
    });
    this.client.connect();
    this.db = this.client.db(dbName);
    this.collection = this.db.collection(collectionName);
    this.cache = new Map();
  }

  async set(_id, datas) {
    const now = Date.now();
    const data = Object.assign((await this.get(_id)) || {}, datas);
    this.cache.set(_id, { t: now, v: data });
    for (const [i, d] of this.cache.entries())
      if (now > d.t + 60_000 * 5) this.cache.delete(i);
    delete data._id;
    return this.collection.replaceOne({ _id }, data, { upsert: true });
  }

  get(_id) {
    const data = this.cache.get(_id);
    if (!data)
      return new Promise(async (resolve) => {
        const res = await this.collection.findOne({ _id });
        if (res) this.cache.set(_id, { t: Date.now(), v: res });
        resolve(res);
      });
    return data.v || null;
  }

  getAll() {
    return this.collection.find().toArray();
  }

  del(_id) {
    this.cache.delete(_id);
    return this.collection.deleteMany({ _id });
  }
}

class JSONFile {
  constructor(file) {
    this.file = file;
  }

  read() {
    this.data = this.data || {};
    if (fs.existsSync(this.file)) {
      return new Promise((resolve, reject) => {
        const readStream = fs.createReadStream(this.file, {
          encoding: "utf-8",
        });
        let data = "";
        readStream.on("data", (chunk) => {
          data += chunk;
        });
        readStream.on("end", () => {
          resolve(
            Object.assign(this.data, JSON.parse(data, BufferJSON.reviver)),
          );
          readStream.destroy();
        });
        readStream.on("error", (error) => {
          reject(error);
          readStream.destroy();
        });
      });
    }
  }

  write(data) {
    data = data || this.data;
    if (!data) return this.read();
    const dirname = path.dirname(this.file);
    if (!fs.existsSync(dirname)) fs.mkdirSync(dirname, { recursive: true });
    return new Promise((resolve, reject) => {
      const writeStream = fs.createWriteStream(this.file);
      writeStream.on("error", (error) => {
        reject(error);
        writeStream.destroy();
      });
      writeStream.on("finish", (result) => {
        resolve(result);
        writeStream.destroy();
      });
      writeStream.write(JSON.stringify(data, BufferJSON.replacer));
      writeStream.end();
    });
  }

  set(_id, datas) {
    let data = this.get(_id);
    return (this.data[_id] = Object.assign(data || { _id }, datas));
  }

  get(_id) {
    this.data = this.data || {};
    return this.data[_id];
  }

  getAll() {
    return Object.values(this.data);
  }

  del(_id) {
    this.data = this.data || {};
    return delete this.data[_id];
  }
}

module.exports = { mongoDB, JSONFile };
