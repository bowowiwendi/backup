const fs = require("fs");
const path = require("path");
const util = require("util");
const Baileys = require("baileys");
const db = require("./database.js");
const Print = require("./print.js");
const Connection = require("./connection.js");
const Plugin = require("./plugin.js");

const file = __filename;
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.info("[ UPDATE ]", path.basename(file));
  delete require.cache[file];
  require(file);
});
// random respon bot jika 1 grup lebih dari 1 bot
function isRespond(conn, metadata, group, force) {
  if (!metadata.participants) return true;
  const listJadibot = [...db.conn.keys()].filter(
    (_conn) =>
      (_conn.store.state || _conn.store.cache.get("state")).connection ==
      "open",
  );
  const ngumpul = metadata.participants.filter((v) => {
    if (!listJadibot.some((_conn) => _conn.user.jid == v.id)) return false;
    const user = db.get(v.id);
    return user.setting?.bot && !user.setting?.self;
  });
  const type = force ? "admin" : "normal";
  if (ngumpul.length) {
    if (typeof group.bot != "object") group.bot = {};
    const setRespon = () => {
      let jid = {};
      const getJid = () => {
        const botAdmin = ngumpul.filter((v) => v.admin);
        const res = (force && botAdmin.length ? botAdmin : ngumpul).filter(
          (v) => group.bot[type] != v.id,
        );
        jid = res.length ? res.getRandom() : ngumpul.getRandom();
        return jid.id || getJid();
      };
      group.bot[type] = getJid();
      group.bot["last" + type] = Date.now();
    };
    if (Date.now() - (group.bot["last" + type] || 0) > 60_000 * 5) setRespon();
    return !!force || group.bot[type] == conn.user.jid;
  } else {
    delete group.bot;
    return true;
  }
}

exports.messagesUpsert = async function (conn, m) {
  const Config = require("../config.js");
  if (!m) return;
  let isRespon,
    isPrefix,
    isJadibot,
    isSelf,
    isGroup = m.isGroup;
  db.data = db.data || {};
  const database = await db.handle(conn, m);
  let { user, setting, group } = database;
  try {
    if (
      m.messageTimestamp &&
      Date.now() - 60000 > m.messageTimestamp.toNumber() * 1000
    )
      console.warn(
        `[ ${conn.user.name} ] ignore old message from [ ${m.name} ] ${(Date.now() - m.messageTimestamp.toNumber() * 1000).toTimeString()} ago`,
      );
    if (typeof m.body != "string") return;
    // m.exp = 0;
    const isDeveloper = Config.owner.some(
      ([id]) =>
        id?.toString()?.replace(/[^0-9]/g, "") + "@s.whatsapp.net" == m.sender,
    );
    const isOwner = Boolean(isDeveloper || user.owner?.status);
    const isPremium = Boolean(isDeveloper || user.premium?.status);
    const isModerator = Boolean(isDeveloper || user.moderator?.status);
    const isJadibot =
      isDeveloper ||
      [...db.conn.keys()].some(
        (_conn) =>
          _conn.user.jid == conn.user.jid && _conn.user.jid == m.sender,
      );
    isSelf = !(isOwner || isJadibot) && setting.self;
    const metadata = (m.isGroup ? await conn.store.fetchGroupMetadata(m.chat, conn) : {}) || {};
    const participants = metadata.participants || [];
    const member = participants.find((u) => u.id == m.sender) || {}; // User Data
    const bot = participants.find((u) => u.id == conn.user.jid) || {}; // Your Data
    const isAdmin = isOwner || member.admin || false; // Is User Admin?
    const isBotAdmin = bot.admin || false; // Are you Admin?
    isRespon = isRespond(conn, metadata, group, m.isMe);
    // m.exp += Math.ceil(Math.random() * 10);
    for (const name in Plugin.plugins) {
      const plugin = Plugin.plugins[name];
      if (!plugin) continue;
      if (
        !setting.bot &&
        !["enable", "jadibot", "command"].some((v) => name.includes(v))
      )
        continue;
      if (isSelf && !(name.includes("jadibot") || isJadibot)) continue;
      let usedPrefix = setting.prefix ? "/" : "";
      const prefix = setting.prefix
        ? new RegExp(
            "^[" +
              "xzXZ/!#$%+£¢€¥^°=¶∆×÷π√✓©®:;?&.\\-".replace(
                /[|\\{}()[\]^$+*?.\-\^]/g,
                "\\$&",
              ) +
              "]",
          )
        : "";
      const str2Regex = (str) => str.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&");
      const _prefix = plugin.prefix || plugin.customPrefix || prefix;
      const match = (
        _prefix instanceof RegExp // RegExp Mode?
          ? [[_prefix.exec(m.body), _prefix]]
          : Array.isArray(_prefix) // Array?
            ? _prefix.map((p) => {
                let re =
                  p instanceof RegExp // RegExp in Array?
                    ? p
                    : new RegExp(str2Regex(p));
                return [re.exec(m.body), re];
              })
            : typeof _prefix === "string" // String?
              ? [
                  [
                    new RegExp(str2Regex(_prefix)).exec(m.body),
                    new RegExp(str2Regex(_prefix)),
                  ],
                ]
              : [[[], new RegExp()]]
      ).find((p) => p[1]);
      if (!isPrefix) isPrefix = (match[0] || "")[0];
      let extra = {
        isSelf,
        isGroup,
        isDeveloper,
        isOwner,
        isPremium,
        isModerator,
        isJadibot,
        isAdmin,
        isBotAdmin,
        prefix,
        match,
        usedPrefix,
        metadata,
        participants,
        m,
        Config,
        Simple: require("./simple.js"),
        Connection,
        conn,
        sock: conn,
        store: conn.store,
        Baileys,
        Plugin,
        ...database,
        db,
      };
      if (typeof plugin.all === "function") {
        if (
          !isRespond(
            conn,
            metadata,
            group,
            m.isMe ||
              plugin.botadmin ||
              plugin.needadmin ||
              (!m.isGroup && plugin.allchat),
          )
        )
          continue;
        if (setting.onlygroup && !m.isGroup && !(isPremium || isOwner) && !plugin.allchat) {
          setting.onlyprivate = false;
          continue;
        }
        if (setting.onlyprivate && isGroup && !(isPremium || isOwner)) {
          setting.onlygroup = false;
          continue;
        }
        try {
          await plugin.all.call(conn, m, extra);
          continue;
        } catch (e) {
          console.error(e);
          continue;
        }
      }
      if (m.isBot) continue;
      if (typeof plugin.before === "function") {
        if (
          !isRespond(
            conn,
            metadata,
            group,
            m.isMe ||
              plugin.botadmin ||
              plugin.needadmin ||
              (!m.isGroup && plugin.allchat),
          )
        )
          continue;
        if (setting.onlygroup && !m.isGroup && !(isPremium || isOwner) && !plugin.allchat) {
          setting.onlyprivate = false;
          continue;
        }
        if (setting.onlyprivate && m.isGroup && !(isPremium || isOwner)) {
          setting.onlygroup = false;
          continue;
        }
        try {
          await plugin.before.call(conn, m, extra);
          continue;
        } catch (e) {
          console.error(e);
          continue;
        }
      }
      if (!(typeof plugin.run == "function" || typeof plugin == "function"))
        continue;
      if (
        !isRespond(
          conn,
          metadata,
          group,
          m.isMe ||
            plugin.botadmin ||
            plugin.needadmin ||
            (!m.isGroup && plugin.allchat),
        )
      )
        continue;
      if (!m.body) continue;
      usedPrefix = "";
      const setPrefix =
        plugin.prefix || plugin.customPrefix || setting.prefix
          ? (usedPrefix = (match[0] || "")[0])
          : true;
      if (setPrefix) {
        const noPrefix =
          plugin.prefix || plugin.customPrefix || setting.prefix
            ? m.body.replace(usedPrefix, "")
            : m.body;
        let [command, ...args] = noPrefix.trim().split` `.filter((v) => v);
        args = args || [];
        const text = noPrefix.trim().split` `.slice(1).join` `;
        command = (command || "").toLowerCase();
        const isAccept = (cmd) =>
          cmd instanceof RegExp // RegExp Mode?
            ? cmd.test(command)
            : Array.isArray(cmd) // Array?
              ? cmd.some((v) =>
                  v instanceof RegExp // RegExp in Array?
                    ? v.test(command)
                    : v.split(" ").filter((v) => v)[0] === command,
                )
              : typeof cmd === "string" // String?
                ? cmd.split(" ").filter((v) => v)[0] === command
                : plugin.customPrefix || plugin.prefix
                  ? true
                  : false;
        if (
          !(
            isAccept(plugin.cmd) ||
            isAccept(plugin.command) ||
            isAccept(plugin.hidden) ||
            isAccept(plugin.usage) ||
            isAccept(plugin.help)
          )
        )
          continue;
        extra = {
          ...extra,
          noPrefix,
          usedPrefix,
          command,
          args,
          text,
        };
        Object.defineProperty(m, "plugin", {
          enumerable: false,
          writable: true,
          value: {
            ...plugin,
            usedPrefix,
            command,
            name,
          },
        });
        if (setting.onlygroup && !m.isGroup && !(isPremium || isOwner) && !plugin.allchat) {
          setting.onlyprivate = false;
          conn.warning = conn.warning || [];
          if (!conn.warning.includes(m.sender)) {
            Config.msg("onlygroup", m);
            conn.warning.push(m.sender);
          } else {
            delete m.plugin;
            isRespon = false;
          }
          continue;
        }
        if (setting.onlyprivate && m.isGroup && !(isPremium || isOwner) && !plugin.allchat) {
          setting.onlygroup = false;
          conn.warning = conn.warning || [];
          if (!conn.warning.includes(m.sender)) {
            Config.msg("onlyprivate", m);
            conn.warning.push(m.sender);
          } else {
            delete m.plugin;
            isRespon = false;
          }
          continue;
        }
        if ((group.banned || user.banned) && !name.includes("ban")) {
          continue;
        }
        if (plugin.developer && !isDeveloper) {
          Config.msg("developer", m);
          continue; // Developer Both
        }
        if (plugin.owner && !isOwner) {
          Config.msg("owner", m);
          continue; // User Owner
        }
        if (plugin.jadibot && !isJadibot) {
          Config.msg("jadibot", m);
          continue; // User Jadibot
        }
        if (plugin.premium && !isPremium) {
          Config.msg("premium", m);
          continue; // User Premium
        }
        if (plugin.moderator && !isModerator) {
          Config.msg("moderator", m);
          continue; // User Moderator
        }
        if (plugin.group && !m.isGroup) {
          Config.msg("group", m);
          continue; // Group Chat Only
        }
        if (plugin.private && m.isGroup) {
          Config.msg("private", m);
          continue; // Private Chat Only
        }
        if (plugin.admin && !isAdmin) {
          Config.msg("admin", m);
          continue; // User Admin
        }
        if (plugin.botadmin && !isBotAdmin) {
          Config.msg("botadmin", m);
          continue; // You Admin
        }
        if (plugin.limit > user.limit && !isPremium) {
          Config.msg("limit", m);
          continue; // Limit habis
        }
        if (plugin.level > user.level) {
          Config.msg("level", m);
          continue; // Level belum tercapai
        }
        m.exp += "exp" in plugin ? +plugin.exp : 15; // XP Earning per command
        try {
          if (typeof plugin.run == "function")
            await plugin.run.call(conn, m, extra);
          else await plugin.call(conn, m, extra);
          if (!isPremium)
            m.limit =
              (["number", "boolean"].includes(typeof m.limit)
                ? m.limit
                : plugin.limit) || false;
        } catch (e) {
          m.error = true;
          const text = util.format(e);
          for (let url of text.split(" ").filter(v => /http/.test(v)))
            for (let name in Config.api)
              if (new RegExp(Config.api[name][0], "i").test(url))
                for (const key of Config.api[name].slice(1))
                  text = text.replace(new RegExp(key, "g"), "#HIDDEN#");
          if (e?.name) {
            console.error(e);
            const jidOwner = Config.owner[0][0] + "@s.whatsapp.net";
            let txt = "*COMMAND - ERROR*\n\n";
            txt += `Plugin: ${name}\n`;
            txt += `Chat: ${m.chat.split("@").join(" ")}\n`;
            txt += `Name: ${conn.getName(m.chat)}\n`;
            txt += `Sender: @${m.sender.split("@")[0]}\n`;
            txt += `Command: ${usedPrefix + command} ${args.join(
              " ",
            )}\n`;
            txt += `\n\`\`\`${text}\`\`\``;
            m.reply("Maaf tidak dapat memproses permintaan anda!").then(async (sel) => {
              if (Config.system.dev) {
                if ((await conn.fetchBlocklist()).includes(jidOwner))
                  await conn.updateBlockStatus(jidOwner, "unblock");
                m.reply(txt, jidOwner, {
                  mentions: [m.sender],
                });
              }
            });
            continue;
          }
          m.reply(text);
        } finally {
          if (typeof plugin.after === "function") {
            try {
              await plugin.after.call(conn, m, extra);
            } catch (e) {
              console.error(e);
            }
          }
          if (m.exp) user.exp += m.exp;
          if (m.limit) {
            user.limit -= +m.limit;
            // await m.reply(`\`\`\`${+m.limit} Limit terpakai\n${user.limit} Limit tersisa\`\`\``)
          }
        }
      }
    }
  } catch (error) {
    console.error(error);
  } finally {
    if (m.plugin) {
      m.autoRead = true;
      setting.hittoday = (setting.hittoday || 0) + 1;
      setting.hittotal = (setting.hittotal || 0) + 1;
    }
    try {
      if (Config.system.print) await Print(conn, m);
    } catch (e) {
      console.error(e);
    }
    if (m.autoRead && !m.isMe) {
      // autoread chat group
      if (setting.autoreadgc && m.isGroup) conn.readMessages([m.key]);
      // autoread chat private
      if (setting.autoreadpc && !m.isGroup) conn.readMessages([m.key]);
    }
    // autoread story & copy story to jid
    if (m.broadcast && !m.isMe) {
      conn.sendPresenceUpdate(setting.online ? "available" : "unavailable");
      if (setting.autoreadsw) conn.readMessages([m.key]);
    }
  }
  if (Config.test || !setting.bot || !m.body) return;
  await db.set(m.sender, user); 
  if (m.isGroup) await db.set(m.chat, group);
};

exports.participantsUpdate = async function (conn, content) {
  const Config = require("../config.js");
  const { id, participants, action } = content;
  const { setting, group } = await db.handle(conn, id);
  if (setting.self || !group.welcome) return;
  let text = "";
  const metadata = await conn.store.fetchGroupMetadata(id, conn);
  if (!isRespond(conn, metadata, group)) return;
  switch (action) {
    case "add":
    case "remove":
      text =
        action == "add"
          ? group.sWelcome || "Hi @user\nWelcom in group\n@subject\n\n@desc"
          : group.sBye || "Good Bye @user";
      text = text
        .replace(
          "@user",
          participants.map((v) => `@${v.split("@")[0]}`).join(" "),
        )
        .replace("@subject", metadata.subject || "Unknown subject")
        .replace("@desc", metadata.desc || "");
      if (action == "add") 
        return conn.sendButton(     
          id,
          "",
          text,
          "", 
          [
            // cara nambahnya cukup salin dari sini
            { 
              type: "quick_reply",
              button: {
                display_text: "Store List",
                id: setting.prefix ? ".list" : "list"
              }
            },
            // sampe sini
          ],
          null, 
          {
            contextInfo: {
              mentionedJid: participants,
              expiration: metadata.ephemeralDuration,
            }
          }
        )
      conn.sendMessage(
        id,
        { text },
        {
          ephemeralExpiration: metadata.ephemeralDuration,
        },
      );
      break;
    case "promote":
    case "demote":
      text =
        action == "promote"
          ? group.sPromote || "@user ```is now Admin```"
          : group.sDemote || "@user ```is no longer Admin```";
      text = text.replace(
        "@user",
        participants.map((v) => `@${v.split("@")[0]}`).join(" "),
      );
      conn.sendMessage(
        id,
        { text },
        {
          ephemeralExpiration: metadata.ephemeralDuration,
        },
      );
      break;
  }
};

exports.groupsUpdate = async function (conn, content) {
  const Config = require("../config.js");
  for (const groupUpdate of content) {
    const id = groupUpdate.id;
    const { setting, group } = await db.handle(conn, id);
    if (setting.self || !group.detect) continue;
    let text = "";
    const metadata = await conn.store.fetchGroupMetadata(id, conn);
    if (!isRespond(conn, metadata, group)) continue;
    if (groupUpdate.desc)
      text = (
        group.sDesc || "```Description has been changed to```\n@desc"
      ).replace("@desc", groupUpdate.desc);
    if (groupUpdate.subject)
      text = (
        group.sSubject || "```Subject has been changed to```\n@subject"
      ).replace("@subject", groupUpdate.subject);
    if (groupUpdate.icon)
      text = (group.sIcon || "```Icon has been changed to```").replace(
        "@icon",
        groupUpdate.icon,
      );
    if (groupUpdate.revoke)
      text = (
        group.sRevoke || "```Group link has been changed to```\n@revoke"
      ).replace("@revoke", groupUpdate.revoke);
    if (groupUpdate.announce == true)
      text = group.sAnnounceOn || "```Group has been closed!```";
    if (groupUpdate.announce == false)
      text = group.sAnnounceOff || "```Group has been open!```";
    if (groupUpdate.restrict == true)
      text = group.sRestrictOn || "```Group has been only admin!```";
    if (groupUpdate.restrict == false)
      text = group.sRestrictOff || "```Group has been all participants!```";
    if (!text) continue;
    conn.sendMessage(
      id,
      { text },
      {
        ephemeralExpiration: metadata.ephemeralDuration,
      },
    );
  }
};

exports.deleteUpdate = async function (conn, key) {
  const Config = require("../config.js");
  if (!key || !key.participant || key.fromMe) return;
  let m = conn.store.loadMessage(key.remoteJid, key.id);
  if (!m || m.key.fromMe || m.broadcast) return;
  const { setting, group } = await db.handle(conn, m);
  const metadata =
    (m.isGroup ? await conn.store.fetchGroupMetadata(m.chat, conn) : {}) || {};
  const participants = metadata.participants || [];
  const member = participants.find((u) => u.id == key.participant) || {};
  const isAdmin = member.admin || false;
  if (!isRespond(conn, metadata, group)) return;
  const name = ["apa", "apaan"];
  const url =
    "https://raw.githubusercontent.com/raseldev18/db/master/sticker/" +
    name.getRandom() +
    ".webp";
  if (setting.bot && group.antidelete)
    await conn
      .sendMessage(
        m.chat,
        {
          sticker: { url },
        },
        {
          quoted: m,
          ephemeralExpiration: metadata.ephemeralDuration,
        },
      )
      .then((msg) => {
        if (!isAdmin) conn.sendMessage(m.chat, { forward: m });
      });
};

exports.callUpdate = async function (conn, content) {
  const Config = require("../config.js");
  const max = 5;
  conn.anti = conn.anti || {};
  conn.anti.call = conn.anti.call || {};
  for (const m of content) {
    if (m.status == "offer") {
      if (m.isGroup) continue;
      if (conn.user.jid == m.from) continue;
      const { setting, user } = await db.handle(conn, m.from);
      if (!setting.anticall || user.filter) continue;
      if (!(m.from in conn.anti.call))
        conn.anti.call[m.from] = { warning: 0, audio: 0, video: 0 };
      conn.anti.call[m.from].warning += 1;
      if (!m.isVideo) conn.anti.call[m.from].audio += 1;
      if (m.isVideo) conn.anti.call[m.from].video += 1;
      const hias = `A N T I - ${(m.isVideo ? "video" : "audio")
        .toUpperCase()
        .split("")
        .join(" ")} - C A L L`;
      if (conn.anti.call[m.from].warning >= max) {
        if (typeof user.banned != "object") user.banned = {};
        user.banned.status = true;
        user.banned.time = Date.now() + 86400000;
        user.banned.reason =
          "call " +
          "Audio " +
          conn.anti.call[m.from].audio +
          " Video " +
          conn.anti.call[m.from].video;
        conn.sendText(
          m.from,
          `${title}\n\nMaaf @${parseInt(
            m.from,
          )} peringatan Anda mencapai batas Anda akan di banned dan di block.`,
        );
        const title = `C A L L - N O T I F I C A T I O N S`;
        const thumb = await conn.store.fetchImageUrl(m.from, conn);
        await conn.updateBlockStatus(m.from, "block");
        const txt = `*Audio* : ${conn.anti.call[m.from].audio}
*Video* : ${conn.anti.call[m.from].video}
*At* : ${Date()}

@${parseInt(m.from)} telah menelpon ${conn.user.name}
User telah diblok dan dibanned.`;
        conn.sendText(Config.owner[0][0] + "@s.whatsapp.net", txt, null, {
          title,
          thumb,
          large: true,
          mentions: [m.from],
        });
        delete conn.anti.call[m.from];
        db.set(m.from, user);
      } else {
        conn.sendText(
          m.from,
          `Warning : [ *${
            conn.anti.call[m.from].warning
          }* / *${max}*\nJika Anda mendapatkan *${max}* peringatan, Anda akan secara otomatis di banned dan di block.`,
        );
      }
    }
  }
};
