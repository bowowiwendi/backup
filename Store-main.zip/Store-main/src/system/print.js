const color = require("chalk");
const urlRegex = require("url-regex-safe")();

module.exports = function (conn, m) {
  const me = parseInt(conn.user.jid) + " ~" + conn.user.name;
  const chat = m.chat + " " + conn.getName(m.broadcast ? m.sender : m.chat);
  const sender = parseInt(m.sender) + " ~" + m.name;
  const date =
    new Date(
      m.messageTimestamp?.toNumber
        ? m.messageTimestamp.toNumber() * 1000
        : Date.now(),
    ) + "";
  console.log(`
${"=".repeat(35)}
${color.bold(date)}
${color.red(me)}
${color.cyan(chat)}
${color.green(sender)}
${color.yellow(m.type)}`);
  if (typeof m.body === "string") {
    let log = m.body.replace(/\u200e+/g, "");
    const mdRegex =
      /(?<=(?:^|[\s\n])\S?)(?:([*_~])(.+?)\1|```((?:.||[\n\r])+?)```)(?=\S?(?:[\s\n]|$))/g;
    const mdFormat =
      (depth = 4) =>
      (_, type, text, monospace) => {
        const types = {
          _: "italic",
          "*": "bold",
          "~": "strikethrough",
        };
        text = text || monospace;
        const formatted =
          !types[type] || depth < 1
            ? text
            : color[types[type]](text.replace(mdRegex, mdFormat(depth - 1)));
        return formatted;
      };
    if (log.length < 4001)
      log = log.replace(urlRegex, (url, i, text) => {
        const end = url.length + i;
        return i === 0 ||
          end === text.length ||
          (/^\s$/.test(text[end]) && /^\s$/.test(text[i - 1]))
          ? color.blueBright(url)
          : url;
      });
    log = log.replace(mdRegex, mdFormat(4));
    for (const user of m.mentions)
      log = log.replace(
        "@" + user.split`@`[0],
        color.blueBright("@" + conn.getName(user)),
      );
    console.log(
      m.error != null ? color.red(log) : m.plugin ? color.yellow(log) : log,
    );
  }
  if (m.messageStubParameters?.length)
    console.log(
      m.messageStubParameters
        .map((jid) => {
          return /net/.test(jid)
            ? color.gray(parseInt(jid) + " ~" + conn.getName(jid))
            : color.gray(jid);
        })
        .join(", "),
    );
};
