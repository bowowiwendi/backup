const fs = require("fs");
const path = require("path");
const db = require("./database.js");
const {
  proto,
  toBuffer,
  isJidGroup,
  getContentType,
  jidNormalizedUser,
  downloadMediaMessage,
  extractMessageContent,
  generateWAMessageFromContent, 
  WAMessageStubType,
} = require("baileys");

const file = __filename;
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.info("[ UPDATE ]", path.basename(file));
  delete require.cache[file];
  require(file);
});

exports.HelperConnection = function HelperConnection(conn, store) {
  return Object.defineProperties(conn, {
    sendButton: {
      async value(jid, title, text, footer, buttons, quoted, options) {    
        const btn = []
        for (const v of buttons) 
          btn.push({
            name: v.type || v.name,
            buttonParamsJson: JSON.stringify(v.params || v.param || v.json || v.button || v.buttonParamsJson)
          })
        const m = generateWAMessageFromContent(
          jid, 
          {             
            viewOnceMessage: {                       
              message: {                      
                "messageContextInfo": {                               
                  "deviceListMetadata": {},                
                  "deviceListMetadataVersion": 2       
                },
                interactiveMessage: {             
                  header: {         
                    title, 
                    hasMediaAttachment: false,          
                  },             
                  body: {             
                    text,
                  },
                  footer: {
                    text: footer
                  },
                  nativeFlowMessage: {                
                    buttons: btn,
                  },   
                  ...options,
                },   
              },
            }, 
          }, 
          {
            quoted,
            userJid: conn.user.jid,
            ...options,
          },
        )  
        conn.relayMessage(jid, m.message, {})
        return m
      },
      enumerable: true,
      writable: true,     
    },
    download: {
      async value(m, options) {
        if (typeof options != "object") options = {};
        const msg = m.msg;
        if (!msg) return null;
        if (!(msg.url || msg.directPath || msg.thumbnailDirectPath))
          return null;
        const edit = m.message?.editedMessage?.message?.protocolMessage;
        const stream = await downloadMediaMessage(
          edit
            ? {
                message: {
                  [getContentType(edit.editedMessage)]: msg,
                },
              }
            : m,
          "stream",
          options,
          {
            logger: conn.ws.config.logger,
            reuploadRequest: conn.updateMediaMessage,
          },
        );
        if (options.asStream) return stream;
        return toBuffer(stream);
      },
      enumerable: true,
      writable: true,
    },
    getName: {
      value(jid, withNotify) {
        let name = null;
        if (!jid) return name;
        if (jid == "0@s.whatsapp.net") name = "WhatsApp";
        if (!name) {
          const data = {
            ...store.chats.get(jid),
            ...store.contacts[jid],
            ...store.groupMetadata[jid],
          };
          name =
            data.subject ||
            data.name ||
            data.verifiedBizName ||
            data.verifiedName ||
            data.notify;
        }
        if (!name) {
          const data = {
            ...db.get(jid),
            ...(jid == conn.user.jid ? conn.user : {}),
          };
          name =
            data.subject ||
            data.name ||
            data.verifiedBizName ||
            data.verifiedName ||
            data.notify;
          if (withNotify && !(jid || "").endsWith("g.us"))
            name = `${name} (${data.notify || data.verifiedBizName || data.verifiedName || data.name})`;
        }
        if (typeof name != "string")
          name = jid?.endsWith("g.us") ? "Unknown subject" : parseInt(jid);
        return name;
      },
      enumerable: true,
      writable: true,
    },
    store: {
      get() {
        return store;
      },
      set(value) {
        Object.assign(store, value);
      },
      enumerable: true,
      configurable: true,
    }, 
    user: {
      get() {
        return Object.assign(conn.authState?.creds?.me || {}, {
          jid: jidNormalizedUser(conn.authState?.creds?.me?.id),
        });
      },
      set(value) {
        return Object.assign(conn.authState?.creds?.me || {}, value);
      },
      enumerable: true,
      configurable: true,
    },
  });
};

exports.smsg = smsg;
function smsg(conn, m) {
  if (!m) return m;
  m = proto.WebMessageInfo.fromObject(m);
  Object.defineProperty(m, "conn", {
    enumerable: false,
    writable: true,
    value: conn,
  });
  let protocolMessage = m.message?.[m.type];
  if (
    m.type == "protocolMessage" &&
    protocolMessage?.key &&
    !protocolMessage.editedMessage
  ) {
    protocolMessage.key.participant = m.sender;
    protocolMessage.key.fromMe =
      protocolMessage.key.participant == conn.user.jid;
    conn.ev.emit("messages.delete", { keys: [protocolMessage.key] });
  }
  return m;
}

const BOT_IDS = "@|acel|3eb0|bae5|wbsf|cyber|crux|suhail";
exports.serialize = () => {
  return Object.defineProperties(proto.WebMessageInfo.prototype, {
    id: {
      get() {
        return this.key?.id;
      },
    },
    chat: {
      get() {
        return this.key?.remoteJid;
      },
    },
    sender: {
      get() {
        return (
          (this.key?.fromMe && this.conn?.user?.jid) ||
          this.key?.participant ||
          this?.participant ||
          this.chat
        );
      },
    },
    name: {
      get() {
        return (
          this.verifiedName || this.pushName || this.conn?.getName(this.sender)
        );
      },
    },
    isMe: {
      get() {
        return this.key?.fromMe;
      },
    },
    isBot: {
      get() {
        return new RegExp(BOT_IDS, "i").test(this.id);
      },
    },
    isGroup: {
      get() {
        return isJidGroup(this.chat);
      },
    },
    msg: {
      get() {
        if (!this.message) return null;
        const findMsg = (message) => {
          const type = getContentType(message?.message || message);
          if (!type) return null;
          const msg = (message?.message || message)[type];
          const data = findMsg(msg) || msg;
          if (msg?.editedMessage && data?.caption) {
            const msgStore =
              this.conn.store.loadMessage(msg.key.remoteJid, msg.key.id) ||
              this.conn.store.loadMessage(msg.key.id);
            if (msgStore) {
              const msg2 = proto.WebMessageInfo.fromObject(msgStore);
              msg2.msg.caption = data.caption;
              return msg2.msg;
            }
          }
          return data;
        };
        return findMsg(extractMessageContent(this.message));
      },
    },
    mentions: {
      get() {
        return this.msg?.contextInfo?.mentionedJid || [];
      },
    },
    type: {
      get() {
        if (!this.message) return WAMessageStubType[this.messageStubType];
        return getContentType(this.message) || Object.keys(this.message)[0];
      },
    },
    body: {
      get() {
        const msg = this.msg;
        return typeof this._body === "string"
          ? this._body
          : typeof msg === "string"
            ? msg
            : msg?.text ||
              msg?.caption ||
              msg?.contentText ||
              msg?.hydratedTemplate?.hydratedContentText ||
              "";
      },
      set(str) {
        return (this._body = str);
      },
    },
    download: {
      value(saveToFile = false, asStream = false) {
        return this.conn?.download(this, { saveToFile, asStream });
      },
    },
    delete: {
      value() {
        return this.conn?.sendMessage(this.chat, { delete: this.key });
      },
    },
    reply: {
      value(text, chatId, options) {
        const jid = chatId || this.chat;
        const chat = this.conn.store.groupMetadata[jid] || this.conn.store.chats.get(jid);
        return this.conn?.sendMessage(jid, { text, ...options }, {
          ephemeralExpiration: chat?.ephemeralDuration || chat?.ephemeralExpiration || this.msg?.contextInfo?.expiration,
          quoted: this,
          ...options,
        });
      },
    },
    react: {
      value(text, key) {
        return this.conn?.sendMessage(this.chat, {
          react: { text, key: key || this.key },
        });
      },
    },
    forward: {
      value(jid, force = false, options) {
        jid = jid || this.chat;
        const chat = this.conn.store.groupMetadata[jid] || this.conn.store.chats.get(jid);
        return this.conn?.sendMessage(
          jid,
          { forward: this, force, ...options },
          {
            ephemeralExpiration: chat?.ephemeralDuration || chat?.ephemeralExpiration || this.msg?.contextInfo?.expiration,
            ...options,
          },
        );
      },
    },
    quoted: {
      get() {
        const contextInfo = this.msg?.contextInfo;
        if (!contextInfo?.quotedMessage) return null;
        const remoteJid = contextInfo.remoteJid || this.chat;
        const participant = contextInfo.participant || remoteJid;
        return smsg(
          this.conn,
          proto.WebMessageInfo.fromObject({
            key: {
              remoteJid,
              fromMe: this.conn?.user?.jid == participant,
              id: contextInfo.stanzaId,
              participant: isJidGroup(remoteJid) ? participant : undefined,
            },
            message: contextInfo.quotedMessage,
          }),
        );
      },
    },
    getQuotedObj: {
      value() {
        const q = this.quoted;
        if (!q) return null;
        let m =
          this.conn?.store.loadMessage(q.chat, q.id) ||
          this.conn?.store.loadMessage(q.id);
        return smsg(this.conn, m || q);
      },
    },
  });
};

exports.protoType = () => {
  /**
   * @returns {ArrayBuffer}
   */
  Buffer.prototype.toArrayBuffer = function toArrayBuffer() {
    const ab = new ArrayBuffer(this.length);
    const view = new Uint8Array(ab);
    for (let i = 0; i < this.length; ++i) {
      view[i] = this[i];
    }
    return ab;
  };
  /**
   * @returns {ArrayBuffer}
   */
  Buffer.prototype.toArrayBufferV2 = function toArrayBufferV2() {
    return this.buffer.slice(
      this.byteOffset,
      this.byteOffset + this.byteLength,
    );
  };
  /**
   * @returns {Buffer}
   */
  ArrayBuffer.prototype.toBuffer = function toBuffer() {
    const buf = Buffer.alloc(this.byteLength);
    const view = new Uint8Array(this);
    for (let i = 0; i < buf.length; ++i) {
      buf[i] = view[i];
    }
    return buf;
  };
  /**
   * @returns {Boolean}
   */
  String.prototype.isNumber = Number.prototype.isNumber = function isNumber() {
    const int = parseInt(this);
    return typeof int === "number" && !isNaN(int);
  };
  /**
   * @returns {String}
   */
  String.prototype.capitalize = function capitalize() {
    return this.charAt(0).toUpperCase() + this.slice(1, this.length);
  };
  /**
   * @returns {String}
   */
  String.prototype.capitalizeV2 = function capitalizeV2() {
    const str = this.split(" ");
    return str.map((v) => v.capitalize()).join(" ");
  };
  /**
   * @returns {String}
   */
  String.prototype.decodeJid = function decodeJid() {
    return jidNormalizedUser(this);
  };
  /**
   * Number must be milliseconds
   * @returns {string}
   */
  Number.prototype.toTimeString = function toTimeString(isMillisecond) {
    const milliseconds = this % 1000;
    const seconds = Math.floor((this / 1000) % 60);
    const minutes = Math.floor((this / (60 * 1000)) % 60);
    const hours = Math.floor((this / (60 * 60 * 1000)) % 24);
    const days = Math.floor(this / (24 * 60 * 60 * 1000));
    return (
      (days ? `${days} day(s) ` : "") +
      (hours ? `${hours} hour(s) ` : "") +
      (minutes ? `${minutes} minute(s) ` : "") +
      (seconds ? `${seconds} second(s) ` : "") +
      (isMillisecond
        ? milliseconds
          ? `${milliseconds} millisecond(s) `
          : ""
        : "")
    ).trim();
  };
  Number.prototype.getRandom =
    String.prototype.getRandom =
    Array.prototype.getRandom =
      function getRandom() {
        if (Array.isArray(this) || typeof this == "string")
          return this[Math.floor(Math.random() * this.length)];
        return Math.floor(Math.random() * this);
      };
};
/**
 * ??
 * @link https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Nullish_coalescing_operator
 * @returns {boolean}
 */
function nullish(args) {
  return !(args !== null && args !== undefined);
}
