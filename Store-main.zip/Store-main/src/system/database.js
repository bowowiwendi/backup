const Config = require("../config.js");
const { mongoDB, JSONFile } = require("./adapter.js");

const isNumber = (x) => typeof x === "number" && !isNaN(x);
const type = Config.db || "db";
let auth = null;
const db = /mongodb(\+srv)?:\/\//i.test(type)
  ? new mongoDB(type, "WhatsApp", "data")
  : new JSONFile(type.replace(/\.?json/i, ".json"));

db.handle = handle;
module.exports = db;

async function handle(conn, m = {}) {
  const now = Date.now();
  const botId = typeof conn == "string" ? conn : conn?.jid || conn?.user?.jid;
  const groupId = typeof m == "string" ? m : m?.chat;
  const senderId = typeof m == "string" ? m : m?.sender;
  try {
    // user
    let user = {};
    if (/net|lid/.test(senderId)) {
      user = (await db.get(senderId)) || {};

      if (!("name" in user)) user.name = m?.name || parseInt(senderId);
      
      if (typeof m?.name == "string") user.name = m.name;
      delete user.lastactive;
      user.lastactive = now;
      if (m?.isGroup) user.lastgroup = now;
      else if (m?.key) user.lastprivate = now;
    }
    // group
    let group = {};
    if (/g.us/.test(groupId)) {
      group = (await db.get(groupId)) || {};

      if (!("subject" in group)) group.subject = "Unknown subject";
      if (!("welcome" in group)) group.welcome = false;
      
      if (conn?.getName) group.subject = conn.getName(groupId);
      delete group.lastactive;
      group.lastactive = now;
    }
    // bot
    let setting = {};
    if (botId) {
      if (botId == senderId) {
        setting = user.setting = user.setting || {};
      } else {
        const u = await db.get(botId) || {};
        setting = u.setting = u.setting || {};
      }
      
      if (!("bot" in setting)) setting.bot = true;
      if (!("self" in setting)) setting.self = false;
      if (!("prefix" in setting)) setting.prefix = false;
      if (!("online" in setting)) setting.online = false;
      if (!("anticall" in setting)) setting.anticall = false;
      if (!("autoreadgc" in setting)) setting.autoreadgc = false;
      if (!("autoreadpc" in setting)) setting.autoreadpc = false;
      if (!("autoreadsw" in setting)) setting.autoreadsw = false;
      if (!("onlygroup" in setting)) setting.onlygroup = false;
      if (!("onlyprivate" in setting)) setting.onlyprivate = false;

      delete setting.lastactive;
      setting.lastactive = now;
    }

    return {
      user,
      setting,
      group,
    };
  } catch (e) {
    console.error(e);
    return {};
  }
}
