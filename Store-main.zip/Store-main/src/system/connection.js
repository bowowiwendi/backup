const fs = require("fs");
const path = require("path");
const pino = require("pino");
const {
  STORIES_JID,
  S_WHATSAPP_NET,
  toNumber,
  Browsers,
  BufferJSON,
  makeWASocket,
  getContentType,
  DisconnectReason,
  jidNormalizedUser,
  makeInMemoryStore,
  makeCacheableSignalKeyStore,
  useMultiFileAuthState,
  fetchLatestWaWebVersion,
} = require("baileys");

const db = require("./database.js");
const Config = require("../config.js");
const Simple = require("./simple.js");

const file = __filename;
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.info("[ UPDATE ]", path.basename(file));
  delete require.cache[file];
  require(file);
});

let version = null;
const browser = Browsers.appropriate("Edge");
const P = pino({ level: "silent", timestamp: () => `,"time":"${Date()}"` });

async function start(conn, opts) {
  if (!version) version = (await fetchLatestWaWebVersion()).version;
  const jid =
    (opts.number = opts.number.replace(/[^0-9]/g, "")) + S_WHATSAPP_NET;
  const { user, setting } = await db.handle(jid, jid);
  const folder = path.join("sessions", opts.number);
  const logger = P.child({ class: user?.name || opts.number });
  if (!opts.auth)
    opts.auth = await useMultiFileAuthState((opts.folder = folder));
  console.log("SESSION REGISTERED:", opts.auth.state.creds.registered)
  if (!opts.auth.state.creds.registered && user?.jadibot?.session) {
    const creds = JSON.parse(user.jadibot.session, BufferJSON.reviver);
    Object.assign(opts.auth.state.creds, creds);
  }
  conn = Object.assign(
    conn || {},
    makeWASocket({
      logger,
      version,
      browser,
      auth: {
        ...opts.auth.state,
        keys: makeCacheableSignalKeyStore(opts.auth.state.keys, logger),
      },
      qrTimeout: 60_000,
      syncFullHistory: false,
      defaultQueryTimeoutMs: undefined,
      printQRInTerminal: !opts.number,
      markOnlineOnConnect: !!setting?.online,
      generateHighQualityLinkPreview: true,
      getMessage: (key) => conn.store.messages[key.remoteJid]?.get?.(key.id)?.message,
      patchMessageBeforeSending: (message) => {
        const requiresPatch = !!(
          message.listMessage ||
          message.buttonsMessage ||
          message.templateMessage ||
          message.interactiveMessage
        );
        if (requiresPatch) {
          message = {
            viewOnceMessage: {
              message: {
                messageContextInfo: {
                  deviceListMetadataVersion: 2,
                  deviceListMetadata: {},
                },
                ...message,
              },
            },
          };
        }
        return message;
      },
    }),
  );
  if (!opts.store) {
    opts.store = makeInMemoryStore({
      logger,
      sock: conn,
    });
    opts.store.start = new Date();
    opts.store.isParent = Config.owner.some(([id]) =>
      id.startsWith(opts.number),
    );
  }
  if (!db.conn) db.conn = new Map();
  db.conn.set(conn, opts);
  opts.store.bind(conn.ev);
  Simple.HelperConnection(conn, opts.store);
  reload(conn, opts);
  return conn;
}

async function reload(conn, opts, isRestart) {
  if (isRestart) {
    db.conn.delete(conn);
    try {
      conn.ws.close();
    } catch {}
    conn.ev.removeAllListeners();
    return Object.assign(conn, await start(conn, opts));
  }
  conn.ev.on("connection.update", (content) =>
    connectionUpdate(conn, content, opts),
  );
  conn.ev.on("call", (content) =>
    require("./handler.js").callUpdate(conn, content),
  );
  conn.ev.on("group-participants.update", (content) =>
    require("./handler.js").participantsUpdate(conn, content),
  );
  conn.ev.on("groups.update", (content) =>
    require("./handler.js").groupsUpdate(conn, content),
  );
  conn.ev.on("messages.delete", (content) => {
    const keys = Array.isArray(content.keys)
      ? content.keys
      : Array.isArray(content)
        ? content
        : [content];
    for (const key of keys) require("./handler.js").deleteUpdate(conn, key);
  });
  conn.ev.on("creds.update", async () => {
    if (opts.auth.state.creds.registered) {
      opts.auth.saveCreds();
      const jid = opts.number + S_WHATSAPP_NET;
      const { user } = await db.handle(jid, jid);
      if (typeof user.jadibot != "object") user.jadibot = {};
      user.jadibot.status = true;
      user.jadibot.session = JSON.stringify(
        opts.auth.state.creds,
        BufferJSON.replacer,
      );
      db.set(jid, user);
    }
  });
  conn.ev.on("messages.upsert", (content) => {
    for (let m of content.messages) {
      m = Simple.smsg(conn, m) || m;
      require("./handler.js").messagesUpsert(conn, m);
      const notify = m.verifiedBizName || m.verifiedName || m.pushName;
      const sender = m.key.fromMe
        ? conn.user.jid
        : m.key.participant || m.participant;
      if (m.broadcast) {
        const contact =
          conn.store.readData?.("chat", sender) ||
          conn.store.contacts?.[sender];
        conn.ev.emit("contacts.upsert", [
          {
            id: sender,
            ...(typeof contact?.name == "string"
              ? { notify }
              : { name: notify }),
          },
        ]);
      }
    }
    for (const jid in conn.store.messages) {
      const msgs = conn.store.messages[jid];
      for (const msg of msgs.array) {
        const mtype = getContentType(msg.message);
        if (
          !mtype ||
          /reaction|edited|protocol/i.test(mtype) ||
          Date.now() - msg.messageTimestamp * 1000 >
            (/status/.test(msg.key.remoteJid)
              ? 86400
              : msg.message[mtype]?.contextInfo?.expiration || 86400 * 3) *
              1000
        )
          msgs.remove(msg);
      }
    }
    for (const data of Object.values(conn.store.contacts))
      if (!/net/.test(data.id)) delete conn.store.contacts[data.id];
    //
  });
}

async function connectionUpdate(conn, content, opts) {
  const jid = opts.number + S_WHATSAPP_NET;
  const { user } = await db.handle(jid, jid);
  const {
    receivedPendingNotifications,
    connection,
    lastDisconnect,
    isNewLogin,
    isOnline,
    qr,
  } = content;
  if (receivedPendingNotifications && user) {
    user.jadibot = user.jadibot || {};
    user.jadibot.status = true;
  }
  if (connection) {
    console[connection == "close" ? "error" : "info"](
      `[ ${conn.user.name || user?.name || conn.getName(jid)} ] Connection`,
      connection,
      lastDisconnect?.error?.output?.payload?.statusCode || "",
      lastDisconnect?.error?.output?.payload?.error || "",
      lastDisconnect?.error?.output?.payload?.message || "",
    );
    if (connection == "close") {
      if (
        lastDisconnect?.error?.output?.payload?.statusCode ==
          DisconnectReason.loggedOut ||
        /failure/i.test(lastDisconnect?.error?.output?.payload?.message)
      )
        logout(conn, opts, true);
      else if (/\:/.test(conn.user.id)) reload(conn, opts, true);
    }
  }
  if (qr && opts.number) {
    await new Promise((res) => setTimeout(res, 1000));
    let code = await conn.requestPairingCode(opts.number);
    code = code?.match(/.{1,4}/g)?.join("-") || code;
    console.info(
      "Your Phone Number:", opts.number, "\nYour Pairing Code:", code,
    );
  }
}

async function logout(conn, opts, isLogout) {
  const jid = opts.number + S_WHATSAPP_NET;
  const { user } = await db.handle(jid, jid);
  if (user?.jadibot?.status) user.jadibot.status = false;
  db.conn.delete(conn);
  if (![...db.conn.keys()].length) {
    try {
      conn.end();
    } catch {}
    console.info("Start connection", user.name);
    if (isLogout) {
      conn.ws.config.auth?.clear?.();
      delete opts.auth;
      delete user.jadibot?.session;
      const file = path.join(opts.folder, "creds.json");
       if (fs.existsSync(file)) fs.unlinkSync(file);
    }
    await start(conn, opts);
  } else {
    console.info("Close connection", isLogout ? "logout" : "", user.name);
    if (isLogout) {
      conn.logout();
      delete user?.jadibot?.session;
      await fs.promises.rm(path.join(process.cwd(), opts.folder), {
        recursive: true,
      });
    } else
      try {
        conn.end();
      } catch {}
    conn.store.clear?.();
    conn = opts = null;
  }
  db.set(jid, user);
}

module.exports = {
  start,
  logout,
  reload,
};
