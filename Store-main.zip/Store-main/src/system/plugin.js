const os = require("os");
const fs = require("fs");
const path = require("path");

const rootDirectory = path.join(__dirname, "../");
const pluginFolder = path.join(__dirname, "../../src/plugins");
const pluginFilter = (filename) => /\.(mc)?js$/.test(filename);
let watcher = {};
let plugins = {};

const file = __filename;
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.info("[ UPDATE ]", path.basename(file));
  delete require.cache[file];
  require(file);
  loadPluginFiles()
});

async function loadPluginFiles(Folder = pluginFolder) {
  const folder = path.resolve(Folder);
  if (folder in watcher) return;
  const paths = await fs.promises.readdir(folder);
  await Promise.all(
    paths.map(async (file) => {
      const filename = path.join(folder, file);
      const stats = await fs.promises.stat(filename);
      if (!stats.isFile()) return await loadPluginFiles(filename);
      if (!pluginFilter(filename)) return;
      const formatedFilename = formatFilename(filename);
      try {
        delete require.cache[filename];
        let module = require(filename);
        if (module) {
          if (typeof module?.run == "function" || typeof module == "function") {
            let tags = formatedFilename.split`/`.slice(1)[0] || "";
            if (!pluginFilter(tags)) {
              if (!module.tags) module.tags = tags;
              if (Array.isArray(module.tags) && !module.tags.includes(tags))
                module.tags.push(tags);
              else if (module.tags != tags) module.tags = [module.tags, tags];
            }
          }
          plugins[formatedFilename] = module;
        }
      } catch (e) {
        console.error(e, `error while requiring ${formatedFilename}`);
      }
    }),
  );
  const watching = fs.watch(folder, reload.bind(null, folder));
  watching.on("close", () => deletePluginFolder(folder, true));
  watcher[folder] = watching;
  return (plugins = sortedPlugins(plugins));
}

async function reload(pluginFolder, _ev, file) {
  if (pluginFilter(file)) {
    const filename = path.join(pluginFolder, file);
    const formatedFilename = formatFilename(filename);
    if (formatedFilename in plugins) {
      if (fs.existsSync(filename))
        console.info(`updated plugin - '${formatedFilename}'`);
      else {
        console.warn(`deleted plugin - '${formatedFilename}'`);
        return delete plugins[formatedFilename];
      }
    } else console.info(`new plugin - '${formatedFilename}'`);
    try {
      delete require.cache[filename];
      let module = require(filename);
      if (module) {
        if (typeof module?.run == "function" || typeof module == "function") {
          let tags = formatedFilename.split`/`.slice(1)[0] || "";
          if (!pluginFilter(tags)) {
            if (!module.tags) module.tags = tags;
            if (Array.isArray(module.tags) && !module.tags.includes(tags))
              module.tags.push(tags);
            else if (module.tags != tags) module.tags = [module.tags, tags];
          }
        }
        plugins[formatedFilename] = module;
      }
    } catch (e) {
      console.error(e, `error require plugin '${formatedFilename}'`);
    } finally {
      plugins = sortedPlugins(plugins);
    }
    return true;
  }
}

function deletePluginFolder(folder, isAlreadyClosed = false) {
  const resolved = path.resolve(folder);
  if (!(resolved in watcher)) return;
  if (!isAlreadyClosed) watcher[resolved].close();
  delete watcher[resolved];
}

function formatFilename(filename) {
  let dir = path.join(rootDirectory, "./");
  // fix invalid regular expresion when run in windows
  if (os.platform() === "win32") dir = dir.replace(/\\/g, "\\\\");
  // '^' mean only replace if starts with
  const regex = new RegExp(`^${dir}`);
  const formated = filename.replace(regex, "");
  return formated;
}

function sortedPlugins(plugins) {
  return Object.fromEntries(
    Object.entries(plugins).sort(([a], [b]) => a.localeCompare(b)),
  );
}

module.exports = {
  loadPluginFiles,
  get plugins() {
    return plugins
  }
}
