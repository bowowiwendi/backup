const fs = require("fs");
const os = require("os");
const path = require("path");
const Config = require("./config.js");
const db = require("./system/database.js");
const Connection = require("./system/connection.js");

const file = __filename;
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.info("[ UPDATE ]", path.basename(file));
  delete require.cache[file];
  require(file);
});

function clearTmp() {
  const TIME = 3 * 60 * 1000;
  const clear = (folder) => {
    if (!fs.existsSync(folder)) return;
    for (const i of fs.readdirSync(folder)) {
      const file = path.join(folder, i);
      const stat = fs.statSync(file);
      if (stat.isFile()) {
        if (Date.now() - stat.mtimeMs >= TIME) {
          if (os.platform() === "win32") {
            let fileHandle;
            try {
              fileHandle = fs.openSync(file, "r+");
            } catch (e) {
              console.error("[clearTmp]", e, "Skipping", file);
              return e;
            } finally {
              fileHandle?.close?.();
            }
          }
          fs.unlinkSync(file);
        }
      } else if (stat.isDirectory()) {
        clear(file);
      }
    }
  };
  clear(path.join(process.cwd(), os.tmpdir()));
  for (const i of ["core"])
    if (fs.existsSync(i)) {
      const stat = fs.statSync(i);
      if (stat.isFile()) fs.unlinkSync(i);
      else fs.rmSync(i, { recursive: true });
    }
}

const jadwalSholat = {}

module.exports = async function () {
  if (Config.tes) return;
  clearTmp();
  // auto restart
  if (process.memoryUsage().rss >= Config.limit.ram * 1000000)
    return process.send("reset");
  let isParent = null;
  const d = new Date();
  const date = d.toString();
  const jam = date.split(" ")[4].slice(0, 5);
  // connection
  for (let [conn, opts] of [...db.conn.entries()]) {
    const state = conn.store.state || conn.store.cache.get("state");
    const { setting } = await db.handle(conn, conn.user.jid);
    if (state.connection == "open") { 
      if (!isParent) isParent = conn.store.isParent && conn
    } else if (
      !/\:/.test(conn.user.id) &&
      state.connection != "connecting"
    ) {
      Connection.logout(conn, opts);
    }
  }
  if (db.write) await db.write();
  if (jam.endsWith("00") && isParent && fs.existsSync(db.file))
    isParent.sendMessage(
      Config.owner[0][0] + "@s.whatsapp.net",
      { 
        document: {
          url: db.file,
        }, 
        mimetype: "application/json",
        fileName: path.basename(db.file),
      },
      {
        quoted: {
          key: {
            remoteJid: "status@broadcast",
            fromMe: false,
            participant: 0 + "@s.whatsapp.net",
          },
          message: { conversation: "Backup Database" },
        },
      },
    );
};
