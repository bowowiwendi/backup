process.env.TZ = "Asia/Jakarta";

const fs = require("fs");
const path = require("path");
const file = __filename;
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.info("[ UPDATE ]", path.basename(file));
  delete require.cache[file];
  require(file);
});

module.exports = new (class Config {
  wm = "BR STORE";
  db = "db.json" // mongodb | json
  system = {
    dev: true,
    print: true,
  }; 
  limit = {
    ram: process.env.SERVER_MEMORY || 1024, // mb
    user: 5, // reset limit user
    reset: "17:00",
  };
  bot = "6283153170199" // nomor bot pairing code
  owner = [
    [
      "6283153170199",
    ],
  ];
  api = {
    // name: [url, key, key, key] auto random key
  };
  paydisini = "b50fb0c3ce72f98c3b35275c4cd81b20";
  msg = (type, m) => {
    type = (type || "").toLowerCase();
    let msg = {
      owner: "Perintah ini hanya untuk Owner",
      premium: "Perintah ini hanya untuk user Premium",
      moderator: "Perintah ini hanya untuk Moderator",
      admin: "Perintah ini hanya untuk Admin",
      botadmin: "Perintah ini aktif ketika Bot menjadi Admin",
      group: "Perintah ini hanya bisa di chat Grup",
      private: "Perintah ini hanya bisa di chat Pribadi",
      onlygroup: "Mode Grup, hanya bisa dalam chat grup",
      onlyprivate: "Mode Pribadi, hanya bisa di chat pribadi",
      disable: "Fitur ini tidak aktif",
      fail: "Server sedang error",
   }[type?.toLowerCase?.()];
    if (msg && typeof m?.reply == "function") {
      m.limit = false;
      m.error = true;
      m.autoRead = true
      return m.reply(msg.trim(), null, {
        source: type == "onlygroup" ? this.link.group : false,
        mentions: [...msg.matchAll(/@([0-9]{5,16}|0)/g)].map(
          (v) => v[1] + "@s.whatsapp.net",
        ),
      });
    } else if (msg) return msg.trim();
  };
})();
