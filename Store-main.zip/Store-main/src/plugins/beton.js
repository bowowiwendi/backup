exports.allchat = true;
exports.before = async function (m, { Baileys, Plugin, db, prefix, setting }) {
  // button || number || sticker
  if (
    m.message &&
    (m.message.buttonsResponseMessage ||
      m.message.templateButtonReplyMessage ||
      m.message.listResponseMessage ||
      m.message.interactiveResponseMessage ||
      m.quoted)
  ) {
    let isId = false;
    let id =
      m.message.buttonsResponseMessage?.selectedButtonId ||
      m.message.templateButtonReplyMessage?.selectedId ||
      m.message.listResponseMessage?.singleSelectReply?.selectedRowId ||
      JSON.parse(
        m.message.interactiveResponseMessage?.nativeFlowResponseMessage
          ?.paramsJson || null,
      )?.id ||
      "";
    let text =
      m.message.buttonsResponseMessage?.selectedDisplayText ||
      m.message.templateButtonReplyMessage?.selectedDisplayText ||
      m.message.listResponseMessage?.title ||
      m.message.interactiveResponseMessage?.body?.text ||
      "";
    if (!id || !text) {
      let command = m.getQuotedObj().buttonNumber;
      if (command) {
        let [no, text2] = m.body.split(" ");
        no = parseInt(no.replace(prefix, "")) - 1;
        if (typeof no == "number" && Array.isArray(command)) {
          id = Array.isArray(command[no]) ? command[no]?.[1] : command[no];
          text = Array.isArray(command[no]) ? command[no]?.[0] : command[no];
        } else if (typeof command == "string") {
          id = command + " " + m.body;
          text = "";
        }
      }
    } else if (m.msg?.mediaKey) {
      const command = db.data?.command || {};
      const base64 = Buffer.from(m.msg.mediaKey).toString("base64");
      if (command[base64]) {
        id = command[base64].text;
        text = "";
        m.mentions.concat(command[base64].mentionedJid);
      }
    }
    if (!(id || text)) return;
    for (let name in Plugin.plugins) { 
      const plugin = Plugin.plugins[name];
      if (!plugin) continue;
      let usedPrefix = "";
      const str2Regex = (str) => str.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&");
      const _prefix = plugin.prefix
        ? plugin.prefix
        : plugin.customPrefix
          ? plugin.customPrefix
          : prefix;
      const match = (
        _prefix instanceof RegExp // RegExp Mode?
          ? [[_prefix.exec(id), _prefix]]
          : Array.isArray(_prefix) // Array?
            ? _prefix.map((p) => {
                let re =
                  p instanceof RegExp // RegExp in Array?
                    ? p
                    : new RegExp(str2Regex(p));
                return [re.exec(id), re];
              })
            : typeof _prefix === "string" // String?
              ? [
                  [
                    new RegExp(str2Regex(_prefix)).exec(id),
                    new RegExp(str2Regex(_prefix)),
                  ],
                ]
              : [[[], new RegExp()]]
      ).find((p) => p[1]);
      const setPrefix =
        plugin.prefix || plugin.customPrefix || setting.prefix
          ? (usedPrefix = (match[0] || "")[0])
          : true;
      if (setPrefix) {
        const noPrefix =
          plugin.prefix || plugin.customPrefix || setting.prefix
            ? id.replace(usedPrefix, "")
            : id;
        let [command] = noPrefix.trim().split` `.filter((v) => v);
        command = (command || "").toLowerCase();
        const isAccept = (cmd) =>
          cmd instanceof RegExp // RegExp Mode?
            ? cmd.test(command)
            : Array.isArray(cmd) // Array?
              ? cmd.some((v) =>
                  v instanceof RegExp // RegExp in Array?
                    ? v.test(command)
                    : v.split(" ").filter((v) => v)[0] === command,
                )
              : typeof cmd === "string" // String?
                ? cmd.split(" ").filter((v) => v)[0] === command
                : plugin.customPrefix || plugin.prefix
                  ? true
                  : false;
        if (
          isAccept(plugin.cmd) ||
          isAccept(plugin.command) ||
          isAccept(plugin.hidden) ||
          isAccept(plugin.usage)
        )
          isId = true;
      }
    }
    if (this.isEmit) return delete this.isEmit;
    this.isEmit = true;
    let msg = Baileys.generateWAMessageFromContent(m.chat, m.message, {
      userJid: this.user.id,
      quoted: m.quoted,
    });
    msg.body = isId ? id : text;
    msg.key.fromMe = m.sender == this.user.jid;
    msg.key.id = m.key.id;
    msg.pushName = m.pushName;
    if (Baileys.isJidGroup(m.chat)) msg.key.participant = m.sender;
    setTimeout(() => {
      delete this.isEmit;
    }, 1000);
    this.ev.emit("messages.upsert", {
      messages: [msg],
      type: "append",
      isAccept: true,
    });
  }
};
