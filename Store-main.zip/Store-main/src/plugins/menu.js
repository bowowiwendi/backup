async function handler(
  m,
  {
    Config,
    Baileys,
    Plugin, 
    isGroup,
    isAdmin,
    isDeveloper,
    isJadibot,
    usedPrefix,
    command,
    text,
    setting,
    db, 
  },
) {
  if (!/all/.test(command)) { 
    const sections = []
    const cmd = ["stok", "list", "owner", "payment"]
    for (const v of cmd) 
      sections.push({
        // highlight_label: "label",
        rows: [
          {          
            title: v,
            id: usedPrefix + v,
          }
        ]
      })
    return this.sendButton(
      m.chat, 
      "", 
      `Hi ${m.name}`,
      "", 
      [
        { 
          type: "single_select",
          button: {
            title: "Tap!",
            sections
          }
        }
      ],
      m
    )
  }
  let tags = {};
  const help = Object.values(Plugin.plugins)
    .filter((plugin) => (plugin.help || plugin.usage) && plugin.tags)
    .map((plugin) => {
      return {
        ...plugin,
        tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
        usage: plugin.usage
          ? Array.isArray(plugin.usage)
            ? plugin.usage
            : [plugin.usage]
          : Array.isArray(plugin.help)
            ? plugin.help
            : [plugin.help],
        prefix: Boolean(plugin.customPrefix || plugin.prefix),
      };
    });
  for (let plugin of help)
    if (plugin.tags)
      for (let tag of plugin.tags) if (!tags[tag]) tags[tag] = tag;
  if (!isJadibot) delete tags.bot;
  if (!isGroup || !isAdmin) delete tags.group;
  if (!isDeveloper) delete tags.owner;
  if (text.toLowerCase() in tags)
    tags = { [text.toLowerCase()]: text.toLowerCase() };
  let sections = [],
    buttonNumber = [],
    number = 0,
    menu = [
      ...Object.keys(tags).map((tag) => {
        sections.push({
          title: tags[tag].toUpperCase(),
          rows: []
        })
        return (
          (text.toLowerCase() in tags ? "" : `*${tags[tag].toUpperCase()}*\n`) +
          [
            ...help
              .filter((menu) => menu.tags.includes(tag) && menu.usage)
              .map((menu) => {
                return menu.usage
                  .map((usage, index = 0) => {
                    let info = menu.premium ? premium : menu.limit ? limit : "";
                    let use = menu.use
                      ? `${Array.isArray(menu.use) ? menu.use[index++] || menu.use[0] : menu.use}`
                      : `${usage.split` `.slice(1).join(" ")}`;
                    const prefixCmd = (menu.prefix ? usage : usedPrefix + usage).split` `[0]
                    sections[sections.findIndex(v => v.title.toLowerCase() == tags[tag])].rows.push({
                      // header: info,
                      title: usage.split(" ")[0].capitalize(),
                      // description: use, 
                      id: prefixCmd
                    })
                    buttonNumber.push([
                      usage,
                      prefixCmd,
                    ]);        
                    return `${(number += 1)}. ${menu.prefix ? "" : usedPrefix}${
                      usage.split` `[0]
                    }${use ? " " + `*${use}*` : ""}${info ? " " + info : ""}`;
                  })
                  .join("\n");
              }),
          ].join("\n")
        );
      }),
    ].join("\n\n");
    const d = new Date()
    const txt = `Hi ${m.pushName}
    
Active: ${(d - this.store.start).toTimeString()}`;
    this.sendButton(
        m.chat, 
        "", // title
        txt, // text 
        "", // footer
        [
          {        
            type: "single_select",    
            button: {    
              title: "Tap!",     
              sections,  
            }
          }                                                                                                    
        ],    
        m
      )
}
handler.hidden = ["menu", "help", "allmenu", "menuall"];
module.exports = handler;
