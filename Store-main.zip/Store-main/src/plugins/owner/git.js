const cp = require("child_process");
const { promisify } = require("util");
const exec = promisify(cp.exec).bind(cp);

async function handler(m, { noPrefix, command, text }) {
  if (!noPrefix) return;
  await m.reply("_Executing..._").then(async (msg) => {
    let res;
    try {
      res = await exec(command.trimStart() + " " + text.trimEnd());
    } catch (error) {
      res = error;
    } finally {
      res = (res.stdout || res.stderr).trim();
      if (res) await m.reply(res, null, { edit: msg.key });
    }
  });
}
handler.usage = "$";
handler.prefix = /^[$]/;
handler.developer = true;
module.exports = handler;
