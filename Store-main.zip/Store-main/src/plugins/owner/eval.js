const fs = require("fs");
const path = require("path");
const util = require("util");
const axios = require("axios");

async function handler(m, extra) {
  let { noPrefix, usedPrefix } = extra;
  Object.assign(extra, { fs, path, util, axios })
  if (!noPrefix.length) throw "kode javascript nya mana tuan";
  let _return,
    _syntax = "",
    _text = (/^~/.test(usedPrefix) ? "return " : "") + noPrefix;
  try {
    let exec = new (async () => {}).constructor(
      "argument",
      "require",
      ...Object.keys(extra),
      _text,
    );
    _return = await exec.call(
      this,
      extra,
      require,
      ...Object.keys(extra).map((v) => extra[v]),
    );
  } catch (e) {
    /* 
    let err = require("syntax-error")(_text, "Execution Function", {
      allowReturnOutsideFunction: true,
      allowAwaitOutsideFunction: true,
      sourceType: "module",
    }); */
    // if (err) _syntax = "```" + err + "```\n\n";
    _return = e;
  } finally {
    m.reply(_syntax + util.format(_return));
  }
}
handler.usage = [">", "~>"];
handler.prefix = /^~?>/;
handler.developer = true;
module.exports = handler;
