const paydisini = require("../../system/paydisini.js");

async function handler (m, { Config, conn, isOwner, db, text, usedPrefix, command }) {
  const data = await db.get("store") || {}
  const list = Object.entries(data).filter(([key]) => key != "_id")
  switch(command.replace(/stok/i, "")) {
    case "add":
      if (!isOwner) throw Config.msg("owner")
      let [name, keyAdd, price, desc, d] = text.split(",")
      if (!price && !desc) throw `Example: *${usedPrefix + command}10* ${keyAdd || "kode"},harga,desk,data|data2\n\nContoh data: anu@gmail pw|anu2@gmail pw2`
      keyAdd = keyAdd.toLowerCase()
      if (keyAdd in data) throw `*${keyAdd}* sudah ada`
      data[keyAdd] = { name, price, desc, data: [] }
      if (d) data[keyAdd].data.push(d.split("|").map(v => v.split(" ")))
      db.set("store", data)
      m.reply(`Berhasil menambah *${keyAdd}*`)
      break
    case "adddata": 
      if (!isOwner) throw Config.msg("owner")
      let [keyData, d2] = text.split(",")
      if (!d2) throw `Example: *${usedPrefix + command}* kode,data|data2\n\nContoh data: anu@gmail pw|anu2@gmail pw2`
      keyData = keyData.toLowerCase()
      if (!(keyData in data)) throw `*${keyData}* tidak ada di stok`
      for (const v of d2.split("|")) {
        data[keyData].data.push(v.split(" "))
      }
      db.set("store", data)
      m.reply(`Berhasil menambah data untuk *${keyData}*`)
      break
    case "editdata": 
      if (!isOwner) throw Config.msg("owner")
      let [keyPrice, pr] = text.split(",")
      if (!pr) throw `Example: *${usedPrefix + command}* kode,harga`
      keyPrice = keyPrice.toLowerCase()
      if (!(keyPrice in data)) throw `*${keyPrice}* tidak ada di stok`
      data[keyPrice].price = pr
      db.set("store", data)
      m.reply(`Berhasil mengubah harga *${keyPrice}*`)
      break
    case "deldata": 
      if (!isOwner) throw Config.msg("owner")
      let [keyDel2, index] = text.split(",")
      if (!keyDel2) throw "Gunakan kode!"
      keyDel2 = keyDel2.toLowerCase()
      if (!(keyDel2 in data)) throw `*${keyDel2}* tidak ada di stok`
      index = parseInt(index)
      if (!index) throw `Example: *${usedPrefix + command}* kode,index\n\n${data[keyDel2].data.map((ar, i = 0) => `${i += 1}. ${ar.join("|")}`).join("\n")}`
      if (index > data[keyDel2].data.length) throw `Hanya ada *${data[keyDel2].data.length}* data`
      data[keyDel2].data.splice(index - 1, 1)
      db.set("store", data)
      m.reply(`Berhasil menghapus data *${keyDel2}* pada index *${index}*`)
      break
    case "del":
      if (!isOwner) throw Config.msg("owner")
      let keyDel = text.toLowerCase()
      if (!(keyDel in data)) throw `*${keyDel}* tidak ada`
      delete data[keyDel]
      db.set("store", data)
      m.reply(`Berhasil menghapus *${keyDel}*`)
      break
    case "order":
      if (!list.length) throw "Belum ada stok"
      let [type, amount] = text.split(" ")
      const detail = list.find(([key]) => key == type)?.[1]
      if (!detail) {
        return m.reply("Stok tersebut tidak ada!")
      }
      if (!detail.data.length) throw `Maaf stok *${type}* telah habis!`
      if (amount > detail.data.length) throw `Hanya ada *${detail.data.length}* stok tersedia!`
      const number = parseInt(m.sender);
      const pay = (db.pay = db.pay || new paydisini(Config.paydisini));
      pay[m.sender] = pay[m.sender] || {};
      pay[m.sender][type] = pay[m.sender][type] || {};
      const buy = pay[m.sender][type][amount] = pay[m.sender][type][amount] || {};
      if (buy.msg)  
        return conn.sendMessage(
        m.chat,
        { text: "Selesaikan transaksi anda sebelumnya" },
        { quoted: buy.msg },
      );
    const res = await pay.create(
      detail.price * amount, 
      `${number} order ${type}`,
      {
        ewalet_phone: number,
      },
    );
    if (!res.success) {
      delete db.pay;
      throw res;
    }
    const caption = `*STATUS PEMBAYARAN*
  
Tipe: ${type} 
Jumlah: ${amount}
Deskripsi: ${detail.desc}
Telepon: ${number}
Harga: Rp ${parseInt(res.data.amount).toLocaleString("id")}
Biaya: Rp ${parseInt(res.data.fee).toLocaleString("id")}
Status: ${res.data.status}
Kedaluwarsa: ${res.data.expired}

${res.payment_guide[0].title}${String.fromCharCode(8206).repeat(4001)}
${res.payment_guide[0].content.map((v, i = 0) => `${(i += 1)}. ${v}`).join("\n")}`;
    buy.msg = await conn.sendMessage(m.chat, {
      image: { url: res.data.qrcode_url },
      caption,
    });
    buy.interval = setInterval(async () => {
      const clear = async () => {
        await conn.sendMessage(m.chat, { delete: buy.msg.key });
        clearInterval(buy.interval);
        delete pay[m.sender][type][amount];
        if (!Object.keys(pay[m.sender][type]).length) 
          delete pay[m.sender][type]
        if (!Object.keys(pay[m.sender]).length) delete pay[m.sender];
      };
      if (new Date() > new Date(res.data.expired)) return await clear();
      const check = await pay.check(res.data.unique_code);
      if (check.data.status.toLowerCase() == "success") {
        await clear();
        if (detail.amount && detail.amount != Infinity) detail.amount -= 1	
        const ambil = detail.data.length - amount
        await conn.sendMessage(m.sender, {
          text: `╭─〔 *TRANSAKSI SUKSES* 〕
│ • ID Pembayaran: ${res.data.pay_id}
│ • Nama Produk: ${detail.name}
│ • Desk Produk: ${detail.desc}
│ • Harga Produk: ${detail.price}
│ • Jumlah Beli: ${amount}
│ • Pembeli: ${number}
│ • Waktu Transaksi: ${tampilkanWaktu()}
╰────

〔 *ACCOUNT DETAIL* 〕
${detail.data.slice(ambil).map((ar, i = 0) => `${i += 1}. Email: ${ar.join("\n- Password: ")}`).join("\n")}`,
        });
        detail.data.splice(ambil)
      }
    }, 10_000)
      break
    default:
      if (!list.length) throw "Belum ada stok"
      const cara = `
╭─〔 *BOT AUTO ORDER* 〕
│ • Untuk Membeli Ketik Perintah Berikut
│ • Order Kode(spasi)Jumlah
│ • Contoh: Order yt3b 1
│ • Pastikan Kode & Jumlah Akun di Ketik dengan benar
│ • Kontak admin: ${Config.owner}
╰────\n
`
      sendStok(cara)
  }
  function sendStok(text) {
	let str = text || ""
	for (let [key, data] of list) {
		str += `╭─〔 ${data.name} 〕\n`
		str += `│ • Harga: Rp ${data.price.toLocaleString("id")}\n`
		str += `│ • Stok Tersedia: ${data.data.length}\n`
		str += `│ • Kode: ${key}\n`
		str += `│ • Desk: ${data.desc || ""}\n`
		str += `╰────\n`
	}
	m.reply(str.trim())
  }
}
handler.usage = ["order", "stok", "addstok", "adddata", "editdata", "deldata", "delstok"]
handler.hidden = /^addstok([0-9]+)$/i
module.exports = handler

function tampilkanWaktu() {
  const hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
  const bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];

  const today = new Date();
  const hariIni = hari[today.getDay()];
  const tanggal = today.getDate();
  const bulanIni = bulan[today.getMonth()];
  const tahun = today.getFullYear();
  const jam = today.getHours();
  const menit = today.getMinutes();
  const detik = today.getSeconds();

  const waktu = `${hariIni}, ${tanggal} ${bulanIni} ${tahun} - ${jam}:${menit}:${detik}`;
  
  return waktu;
}
