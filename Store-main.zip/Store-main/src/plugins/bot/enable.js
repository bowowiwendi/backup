async function handler(
  m,
  {
    Config,
    isDeveloper,
    isJadibot,
    isPremium,
    isGroup,
    isAdmin,
    usedPrefix,
    command,
    args,
    setting, 
    group, 
    user, 
  },
) {
  let type = (args[0] || "").toLowerCase().replace("*", "");
  let isEnable = /true|enable|(turn)?on|1/i.test(command);
  let dev = Object.keys(Config.system);
  let sender = Object.entries(user)
    .filter(([_, v]) => typeof v == "boolean")
    .map(([v]) => v);
  let admin = Object.entries(group)
    .filter(([_, v]) => typeof v == "boolean")
    .map(([v]) => v);
  let bot = Object.entries(setting)
    .filter(([_, v]) => typeof v == "boolean")
    .map(([v]) => v);
  let array = [
    ...sender,
    ...(isAdmin ? admin : []),
    ...(isJadibot ? bot : []),
    ...(isDeveloper ? dev : []),
  ].sort((a, b) => a.localeCompare(b));
  if (!setting.bot) array = array.filter((v) => v == "bot" || v == "self");
  let res = array.filter((v) => new RegExp(type).test(v));
  if (res.length > 1) res = res.filter((v) => v == type);
  if (!(type = res[0])) {
    const sections = []
    const getStatus = (type) => {
      let res
      for (const v of array) {
        if (typeof user[type] == "boolean") return res = user[type]
        if (typeof setting[type] == "boolean") return res = setting[type]
        if (typeof group[type] == "boolean") return res = group[type]
      }
      return res
    }
    for (const v of (res.length ? res : array))
      sections.push({
        highlight_label: `${getStatus(v) ? "On" : "Off"}`,
        rows: [
          {
            title: v.capitalize(),
            id: usedPrefix + command + " " + v
         }
        ]
      })
    return this.sendButton(
      m.chat,
      "",
      "Pilih opsi di bawah", 
      "",
      [
        { 
          type: "single_select",
          button: {
            title: "Tap!",
            sections
          }
        }
      ], 
      m
    )    
  }
  if (dev.includes(type)) {
    if (!isDeveloper) return Config.msg("developer", m);
    if (Config.system[type] == isEnable)
      throw `*${type}* sudah *${isEnable ? "nyala" : "mati"}* sebelumnya`;
    Config.system[type] = isEnable;
  }
  if (bot.includes(type)) {
    if (!isJadibot) return Config.msg("jadibot", m);
    if (type == "online")
      this.sendPresenceUpdate(isEnable ? "available" : "unavailable");
    if (setting[type] == isEnable)
      throw `*${type}* sudah *${isEnable ? "nyala" : "mati"}* sebelumnya`;
    setting[type] = isEnable;
  }
  if (admin.includes(type)) {
    if (!isGroup) return Config.msg("group", m);
    if (!isAdmin) return Config.msg("admin", m);
    if (group[type] == isEnable)
      throw `*${type}* sudah *${isEnable ? "nyala" : "mati"}* sebelumnya`;
    group[type] = isEnable;
  }
  if (sender.includes(type)) {
    if (user[type] == isEnable)
      throw `*${type}* sudah *${isEnable ? "nyala" : "mati"}* sebelumnya`;
    user[type] = isEnable;
  }
  console.log(setting)
  m.reply(`*${type}* berhasil di *${isEnable ? "nyala" : "mati"}kan*`);
}
handler.use = "type";
handler.tags = "group";
handler.usage = ["on", "off"];
module.exports = handler;
