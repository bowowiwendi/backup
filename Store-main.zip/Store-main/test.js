const fs = require("fs");
const path = require("path");
const assert = require("assert");
const cp = require("child_process");

function getFiles(folder) {
  let files = [];
  let list = fs.readdirSync(folder);
  list = list.filter((v) => !/node_modules|sessions/.test(v));
  list = list.filter(
    (v) =>
      !v
        .replace(folder, "")
        .replace(folder + "/", "")
        .startsWith("."),
  );
  let listSystem = list.filter((v) => v.includes("system"));
  if (list.includes("plugins")) {
    list = list.filter((v) => !v.includes("system"));
    for (let i of listSystem) list.push(i);
  }
  let listPlugin = list.filter((v) => v.includes("plugins"));
  if (list.includes("plugins")) {
    list = list.filter((v) => !v.includes("plugins"));
    for (let i of listPlugin) list.push(i);
  }
  for (let i of list) {
    let file = path.resolve(path.join(folder, i));
    let stat = fs.statSync(file);
    if (stat.isFile() && file.endsWith("js")) files.push(file);
    if (stat.isDirectory()) for (let i of getFiles(file)) files.push(i);
  }
  return files;
}

for (let file of getFiles(process.cwd())) {
  console.error("Checking", file);
  cp.spawn(process.argv0, ["-c", file])
    .on("close", () => {
      assert.ok(file);
      console.info("Done", file);
    })
    .stderr.on("data", (chunk) => assert.ok(chunk.length < 1, chunk));
}
